# Ti-84PlusCE-Advanced-Chemistry
You must use TI Connect to send this program to your calculator
WARNING:
THE STOICIOMETRY PROGRAM WILL NOT WORK UNLESS YOU DOWNLOAD THAT PROGRAM AS WELL. I separated those two programs as they use too many labels to fit in one single program.
